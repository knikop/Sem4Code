<!-- Konstantinos Nikopoulos & Saqib Ahmad Syed -->
<?php
	require("app/core/init.php");
	new app\core\App();
